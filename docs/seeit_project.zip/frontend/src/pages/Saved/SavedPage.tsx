import { useState } from "react";
import { Users } from "lucide-react";
import { useSavedList } from "../../hooks/useMedia";
import MediaCard from "../Discovery/MediaCard";

const SavedPage = () => {
  const [friendsFilterOn, setFriendsFilterOn] = useState(false);
  const { data: saved, isLoading, isError, error } = useSavedList({
    withFriendsSaved: friendsFilterOn,
  });

  const actionButtonClass =
    "fixed right-5 bottom-5 z-50 flex items-center justify-center bg-neutral-800/80 border-t border-neutral-600 backdrop-blur-md rounded-4xl p-3 text-neutral-300 hover:text-white transition-colors";

  if (isLoading && !saved?.length) {
    return (
      <div className="p-5 grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 xl:grid-cols-8 gap-5">
        {Array.from({ length: 8 }).map((_, idx) => (
          <div key={idx} className="aspect-2/3 w-full rounded-4xl bg-neutral-800/70 animate-pulse" />
        ))}
      </div>
    );
  }
  if (isError) return <p className="p-5 text-red-400">Error: {error?.message}</p>;

  if (!saved?.length)
    return (
      <div className="p-5">
        <p className="text-neutral-400">
          {friendsFilterOn
            ? "No saved items found from you or your friends yet."
            : "No saved items yet. Tap the bookmark on any movie or show's detail page."}
        </p>
        <button
          type="button"
          onClick={() => setFriendsFilterOn((prev) => !prev)}
          className={`${actionButtonClass} ${
            friendsFilterOn ? "bg-emerald-500/80 border-emerald-400 text-white hover:text-white" : ""
          }`}
          title={friendsFilterOn ? "Showing your + friends' saved items" : "Showing only your saved items"}
          aria-pressed={friendsFilterOn}
        >
          <Users size={20} strokeWidth={2.5} />
        </button>
      </div>
    );

  return (
    <div>
      <div className="p-5 grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 xl:grid-cols-8 gap-5">
        {saved.map((item) => (
          <MediaCard key={`${item.media_type}-${item.id}`} item={item} isSaved />
        ))}
      </div>
      <button
        type="button"
        onClick={() => setFriendsFilterOn((prev) => !prev)}
        className={`${actionButtonClass} ${
          friendsFilterOn ? "bg-emerald-500/80 border-emerald-400 text-white hover:text-white" : ""
        }`}
        title={friendsFilterOn ? "Showing your + friends' saved items" : "Showing only your saved items"}
        aria-pressed={friendsFilterOn}
      >
        <Users size={20} strokeWidth={2.5} />
      </button>
    </div>
  );
};

export default SavedPage;
